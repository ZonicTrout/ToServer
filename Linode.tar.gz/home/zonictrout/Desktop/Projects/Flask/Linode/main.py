from flask import Flask

app = Flask(__name__)

@app.route("/")
def hello():
    return "Shhh :)"

@app.route("/CPU")
def CPU():
    with open("./html/CPU.html") as htmlRawCPU:
        return htmlRawCPU.read()

@app.route("/GPU")
def GPU():
    with open("./html/GPU.html") as htmlRawGPU:
        return htmlRawGPU.read()

@app.route("/AIO")
def AIO():
    with open("./html/AIO.html") as htmlRawAIO:
        return htmlRawAIO.read()

@app.route("/RAM")
def RAM():
    with open("./html/RAM.html") as htmlRawRAM:
        return htmlRawRAM.read()

@app.route("/PSU")
def PSU():
    with open("./html/PSU.html") as htmlRawPSU:
        return htmlRawPSU.read()

@app.route("/NSwitch")
def NSwitch():
    with open("./html/NSwitch.html") as htmlRawNSwitch:
        return htmlRawNSwitch.read()

@app.route("/Storage")
def Storage():
    with open("./html/Storage.html") as htmlRawStorage:
        return htmlRawStorage.read()

@app.route("/Keyboard")
def Keyboard():
    with open("./html/Keyboard.html") as htmlRawKeyboard:
        return htmlRawKeyboard.read()

@app.route("/Motherboard")
def Motherboard():
    with open("./html/Motherboard.html") as htmlRawMotherboard:
        return htmlRawMotherboard.read()

@app.route("/OS")
def OS():
    with open("./html/OS.html") as htmlRawOS:
        return htmlRawOS.read()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80)

